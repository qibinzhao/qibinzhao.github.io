import os
import argparse
import json
from train import train
from test import test
from utils import load_data

if __name__ == "__main__":
    OPTIONS = argparse.ArgumentParser()

    OPTIONS.add_argument('-m', '--mode', dest='mode', type=str, default='train', choices=['reproduction', 'train', 'test'])
    OPTIONS.add_argument('-n', '--noise_type', dest='noise_type', type=str, default='random', choices=['random', 'structured'])
    OPTIONS.add_argument('-d', '--dataset', dest='dataset', type=str, default='mosi', choices=['mosi', 'mosei'])
    options = vars(OPTIONS.parse_args())
    mode, dataset, noise_type = options['mode'], options['dataset'], options['noise_type']

    if mode == 'train':
        with open(os.path.join(os.getcwd(), 'settings', 'settings.json'), encoding="utf-8") as f:
            my_settings = json.load(f)
        my_settings["output_path"] = os.path.join(os.getcwd(), 'results')
        my_settings["model_path"] = os.path.join(os.getcwd(), 'models')
        my_settings["data_path"] = os.path.join(os.getcwd(), 'data')
        my_settings['dataset'] = dataset
        my_settings['noise_type'] = noise_type
        train(my_settings)

    elif mode == 'test':
        train_set, valid_set, test_set, input_dims = load_data(os.path.join(os.getcwd(), 'data'), dataset=dataset, noise_type=noise_type, p=0)
        print('Test on {} for {} drop task'.format(dataset, noise_type))
        print('noise_level\t\t', 'Acc2')
        for p in [0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]:
            model_path = os.path.join(os.getcwd(), 'models', "model_TPFN_{}_{}_{}.pt".format(dataset, noise_type, p))
            mae, corr, multi_acc, bi_acc, f1 = test(model_path, test_set, info=False)
            print(p, '\t\t', bi_acc)

    elif mode == 'reproduction':
        train_set, valid_set, test_set, input_dims = load_data(os.path.join(os.getcwd(), 'data'), dataset=dataset, noise_type=noise_type, p=0)
        print('Reproduction on {} for {} drop task'.format(dataset, noise_type))
        print('noise_level\t\t', 'Acc2')
        for p in [0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]:
            model_path = os.path.join(os.getcwd(), 'models', "model_TPFN_{}_{}_{}.pt".format(dataset, noise_type, p))
            mae, corr, multi_acc, bi_acc, f1 = test(model_path, test_set, info=False)
            print(p, '\t\t', bi_acc)