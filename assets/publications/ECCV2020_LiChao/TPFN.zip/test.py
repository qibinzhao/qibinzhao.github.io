from sklearn.metrics import accuracy_score, f1_score
from utils import display
import torch
import numpy as np
import csv
from torch.utils.data import DataLoader


def test(model_path, test_set, output_dim=1, is_cuda=True,  output_path=None, results=None, info=True):
    # noise_type, p, dataset,
    test_iterator = DataLoader(test_set, batch_size=len(test_set), num_workers=4, shuffle=True)
    DTYPE = torch.FloatTensor
    if is_cuda:
        DTYPE = torch.cuda.FloatTensor

    best_model = torch.load(model_path)
    best_model.eval()
    for batch in test_iterator:
        x = batch[:-1]
        x_a = torch.Tensor(x[0].float()).squeeze().type(DTYPE)
        x_v = torch.Tensor(x[1].float()).squeeze().type(DTYPE)
        x_t = torch.Tensor(x[2].float()).type(DTYPE)
        y = torch.Tensor(batch[-1].view(-1, output_dim).float()).type(DTYPE)
        output_test = best_model(x_a, x_v, x_t)
    output_test = output_test.cpu().data.numpy().reshape(-1, output_dim)
    y = y.cpu().data.numpy().reshape(-1, output_dim)
    output_test = output_test.reshape((len(output_test),))
    y = y.reshape((len(y),))
    # calculate metrics
    mae = np.mean(np.absolute(output_test - y))
    corr = round(np.corrcoef(output_test, y)[0][1], 5)
    multi_acc = round(sum(np.round(output_test) == np.round(y)) / float(len(y)), 5)
    true_label = (y >= 0)
    predicted_label = (output_test >= 0)
    bi_acc = accuracy_score(true_label, predicted_label)
    f1 = f1_score(true_label, predicted_label, average='weighted')
    # display
    if info:
        display(mae, corr, multi_acc, bi_acc, f1)
    # save the results of accuracy on binary classification
    if output_path:
        with open(output_path, 'a+') as o:
            writer = csv.writer(o)
            writer.writerow(results + [mae, corr, multi_acc, bi_acc, f1])
    return mae, corr, multi_acc, bi_acc, f1