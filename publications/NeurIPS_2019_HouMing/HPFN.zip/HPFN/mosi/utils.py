from torch.utils.data import Dataset
import h5py

AUDIO = 'covarep'
VISUAL = 'facet'
TEXT = 'glove'
LABEL = 'label'


def total(params):
    """
    count the total number of hyper-parameter settings
    """
    settings = 1
    for k, v in params.items():
        settings *= len(v)
    return settings


def load_mosi(input_dims):
    """
    load MOSI data
    """
    h5f = h5py.File('./data/X_train.h5', 'r')
    x_train = h5f['data'][:]
    h5f.close()
    h5f = h5py.File('./data/y_train.h5', 'r')
    y_train = h5f['data'][:]
    h5f.close()
    h5f = h5py.File('./data/X_valid.h5', 'r')
    x_valid = h5f['data'][:]
    h5f.close()
    h5f = h5py.File('./data/y_valid.h5', 'r')
    y_valid = h5f['data'][:]
    h5f.close()
    h5f = h5py.File('./data/X_test.h5', 'r')
    x_test = h5f['data'][:]
    h5f.close()
    h5f = h5py.File('./data/y_test.h5', 'r')
    y_test = h5f['data'][:]
    h5f.close()

    ad = input_dims[0]
    td = input_dims[2]
    train_set = MOSI(x_train[:, :, td:td + ad], x_train[:, :, td + ad:], x_train[:, :, :td], y_train)
    valid_set = MOSI(x_valid[:, :, td:td + ad], x_valid[:, :, td + ad:], x_valid[:, :, :td], y_valid)
    test_set = MOSI(x_test[:, :, td:td + ad], x_test[:, :, td + ad:], x_test[:, :, :td], y_test)
    return train_set, y_train, valid_set, y_valid, test_set, y_test


class MOSI(Dataset):
    """
    PyTorch Dataset for MOSI
    """
    def __init__(self, audio, visual, text, labels):
        self.audio = audio
        self.visual = visual
        self.text = text
        self.labels = labels

    def __getitem__(self, idx):
        return [self.audio[idx, :, :], self.visual[idx, :, :], self.text[idx, :, :], self.labels[idx]]

    def __len__(self):
        return self.audio.shape[0]