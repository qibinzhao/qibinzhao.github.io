clc; clear all; close all;
%% NOTE
% Benchmark images are randomly selected as latent components to obtain the mixture. In this
% code, we consider the most ideal conditions: we know the exact
% reshuffling operations and number of components. And there is no noise. As the
% results, we hope Reshuffled-TD can be used to perfectly reconstruct each of images
% from the mixture.
%% Parameters
global Sz
N = 3; % number of the components
Sz_ori = [1024, 1024]; % shape of the original data
Sz = Sz_ori*1;
sigma = ones(1,N); % weights on each components
R_ori = {@R1,@R2,@R3,@R4,@R5,@R6,@R7,@R8,@R9,@R10,@R11};
Ri_ori = {@Ri1,@Ri2,@Ri3,@Ri4,@Ri5,@Ri6,@Ri7,@Ri8,@Ri9,@Ri10,@Ri11};
lambda_ori = {1,1,1,1,1,1,1,1,1,1,1,1,1};
%% Component Generation
load 'image.mat';
for i = 1 : size(Y,3)
    tmp = Y(:,:,i);
%     tmp = tmp - mean(tmp(:));
%     tmp = tmp/std(tmp(:));
    data(:,:,i) = imresize(Y(:,:,i),Sz);
end
for i = 1 : N
    A{i} = data(:,:,randi(size(Y,3)));
end
% for i = 1 : N
%     A{i} = data(:,:,i);
% end
%% Reshaping Op. Generation
global ord
for i = 1 : N
    ord{i} = randperm(length(A{i}(:)))';
    b{i} = sigma(i)*A{i}(ord{i});
    b{i} = b{i} - mean(b{i});
end
%% Observation Generation
x = 0;
w = [ 1 1 1]; % assign individual weights for each component
for i = 1 : N
    x = x + w(i)*b{i};
end
%% Decomposition -- RsCA
R = R_ori(1:N);
Ri = Ri_ori(1:N);
lambda = lambda_ori(1:N);
mu = 1;
ro = 1.01;
MaxIter = 10000;
tol = 1e-6;
%% Quantification
% x_tmp = double(uint8((x-min(x))/(max(x)-min(x))*255))/255;
% x_tmp = x_tmp-mean(x_tmp);
x_tmp = x;
%% Algorithm
[ a_esti,f_esti ] = ReshuffledTD( x_tmp, R, Ri,lambda,mu,ro,MaxIter,tol,0);
%% evaluation
% Method 1 -- Overall SIR
SIR = 10*log10(norm(cell2mat(b),'fro')^2/norm(cell2mat(b)- ...
    cell2mat(a_esti(1:N)))^2);
% Method 2 -- 1st-component SIR
SIR1 = 10*log10(norm(cell2mat(b(1)),'fro')^2/norm(cell2mat(b(1))- ...
    cell2mat(a_esti(1)))^2);
disp('==========================================')
disp(['[*] The overall SIR equals ' num2str(SIR)]);
disp(['[*] The 1st-comp. SIR equals ' num2str(SIR1)]);
disp('==========================================')
%% Visualization
for i = 1 : N
    X{1,i} = (R{i}(b{i})-min(b{i}(:)))/(max(b{i}(:))-min(b{i}(:)));
    tmp = R{i}(a_esti{i})+a_esti{N+1}/N;
    X{2,i} = (tmp-min(tmp(:)))/(max(tmp(:))-min(tmp(:)));
end
% subplot(N+1,col,(col+1):(col*(N+1)))
figure;
imshow(cell2mat(X));
title('Ground-truth (the 1st row) and the reconstruction (the 2nd row)')
%% Reshaping Functions
function y = R1(x)
global ord
global Sz
global l_n;
y(ord{1}) = x;
y = reshape(y,Sz);
end
function y = R2(x)
global ord
global Sz
global l_n;
y(ord{2}) = x;
y = reshape(y,Sz);
end
function y = R3(x)
global ord
global Sz
global l_n;
y(ord{3}) = x;
y = reshape(y,Sz);
end
function y = R4(x)
global ord
global Sz
global l_n;
y(ord{4}) = x;
y = reshape(y,Sz);
end
function y = R5(x)
global ord
global Sz
global l_n;
y(ord{5}) = x;
y = reshape(y,Sz);
end
function y = R6(x)
global ord
global Sz
global l_n;
y(ord{6}) = x;
y = reshape(y,Sz);
end
function y = R7(x)
global ord
global Sz
global l_n;
y(ord{7}) = x;
y = reshape(y,Sz);
end
function y = R8(x)
global ord
global Sz
global l_n;
y(ord{8}) = x;
y = reshape(y,Sz);
end
function y = R9(x)
global ord
global Sz
global l_n;
y(ord{9}) = x;
y = reshape(y,Sz);
end
function y = R10(x)
global ord
global Sz
global l_n;
y(ord{10}) = x;
y = reshape(y,Sz);
end
function y = R11(x)
global ord
global Sz
global l_n;
y(ord{11}) = x;
y = reshape(y,Sz);
end
%% Inverse of the Reshaping Functions
function y = Ri1(X)
global ord
y = X(ord{1});
end
function y = Ri2(X)
global ord
y = X(ord{2});
end
function y = Ri3(X)
global ord
y = X(ord{3});
end
function y = Ri4(X)
global ord
y = X(ord{4});
end
function y = Ri5(X)
global ord
y = X(ord{5});
end
function y = Ri6(X)
global ord
y = X(ord{6});
end
function y = Ri7(X)
global ord
y = X(ord{7});
end
function y = Ri8(X)
global ord
y = X(ord{8});
end
function y = Ri9(X)
global ord
y = X(ord{9});
end
function y = Ri10(X)
global ord
y = X(ord{10});
end
function y = Ri11(X)
global ord
y = X(ord{11});
end