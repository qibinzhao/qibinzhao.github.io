import h5py
import numpy as np
from torch.utils.data import Dataset


class LoadDataSet(Dataset):
    def __init__(self, audio, visual, text, labels, is_time=False):
        self.is_time = is_time
        if is_time:
            self.audio = audio
            self.visual = visual
            self.text = text
            self.labels = labels
        else:
            self.audio = np.mean(audio, axis=1)
            self.visual = np.mean(visual, axis=1)
            self.text = text
            self.labels = labels

    def __getitem__(self, idx):
        if self.is_time:
            return [self.audio[idx, :, :], self.visual[idx, :, :], self.text[idx, :, :], self.labels[idx]]
        else:
            return [self.audio[idx, :], self.visual[idx, :], self.text[idx, :, :], self.labels[idx]]

    def __len__(self):
        return self.audio.shape[0]


# random drop for raw data
def random_drop(x, p, seed=0):
    np.random.seed(seed)
    p = max(0, min(1, p))
    batch_size = x.shape[0]
    time_step = x.shape[1]
    new_x = x.copy()
    try:
        new_x = new_x.view(batch_size, -1)
    except:
        new_x = np.reshape(new_x, newshape=[batch_size, -1])
    num_feature = new_x.shape[1]
    for i in range(batch_size):
        for j in range(num_feature):
            r = np.random.random()
            if r < p:
                new_x[i, j] = 0
    try:
        new_x = new_x.view(batch_size, time_step, -1)
    except:
        new_x = np.reshape(new_x, newshape=[batch_size, time_step, -1])
    return new_x


# structured drop for raw data
def structured_drop(x, p, seed=0):
    np.random.seed(seed)
    p = max(0, min(1, p))
    time_step = x.shape[1]
    new_x = x.copy()
    for t in range(time_step):
        r = np.random.random()
        if r < p:
            # drop the whole entries for this time step
            new_x[:, t, :] = 0
    return new_x


# load mosi/mosei from data_path, is_time means whether to retain the dimension of time or not.
def load_data(data_path, is_time=False, dataset='mosi', noise_type=None, p=0):
    if dataset == 'mosi':
        data_path += '/mosi'
        # load raw data
        h5f = h5py.File(data_path + '/X_train.h5', 'r')
        x_train = h5f['data'][:]
        h5f.close()
        h5f = h5py.File(data_path + '/y_train.h5', 'r')
        y_train = h5f['data'][:]
        h5f.close()
        h5f = h5py.File(data_path + '/X_valid.h5', 'r')
        x_valid = h5f['data'][:]
        h5f.close()
        h5f = h5py.File(data_path + '/y_valid.h5', 'r')
        y_valid = h5f['data'][:]
        h5f.close()
        h5f = h5py.File(data_path + '/X_test.h5', 'r')
        x_test = h5f['data'][:]
        h5f.close()
        h5f = h5py.File(data_path + '/y_test.h5', 'r')
        y_test = h5f['data'][:]
        h5f.close()
        d_l, d_a, d_v = 300, 5, 20
        time_step = 20
        input_dims = (d_a, d_v, d_l)
        audio_train = x_train[:, :, d_l:d_l + d_a]
        video_train = x_train[:, :, d_l + d_a:]
        text_train = x_train[:, :, :d_l]
        # drop data
        if noise_type != None:
            if noise_type == 'random':
                audio_train = random_drop(audio_train, p=p)
                video_train = random_drop(video_train, p=p)
                text_train = random_drop(text_train, p=p)
            elif noise_type == 'structured':
                audio_train = structured_drop(audio_train, p=p)
                video_train = structured_drop(video_train, p=p)
                text_train = structured_drop(text_train, p=p)
        train_set = LoadDataSet(audio_train, video_train, text_train, y_train, is_time=is_time)
        valid_set = LoadDataSet(x_valid[:, :, d_l:d_l + d_a], x_valid[:, :, d_l + d_a:], x_valid[:, :, :d_l], y_valid, is_time=is_time)
        test_set = LoadDataSet(x_test[:, :, d_l:d_l + d_a], x_test[:, :, d_l + d_a:], x_test[:, :, :d_l], y_test, is_time=is_time)
        if is_time:
            input_dims = (d_a, d_v, d_l, time_step)
    elif dataset == 'mosei':
        data_path += '/mosei'
        # load train
        h5f = h5py.File(data_path + '/audio_train.h5', 'r')
        audio_train = h5f['d1'][:]
        h5f.close()
        h5f = h5py.File(data_path + '/video_train.h5', 'r')
        video_train = h5f['d1'][:]
        h5f.close()
        h5f = h5py.File(data_path + '/text_train_emb.h5', 'r')
        text_train = h5f['d1'][:]
        h5f.close()
        # load valid
        h5f = h5py.File(data_path + '/audio_valid.h5', 'r')
        audio_valid = h5f['d1'][:]
        h5f.close()
        h5f = h5py.File(data_path + '/video_valid.h5', 'r')
        video_valid = h5f['d1'][:]
        h5f.close()
        h5f = h5py.File(data_path + '/text_valid_emb.h5', 'r')
        text_valid = h5f['d1'][:]
        h5f.close()
        # load test
        h5f = h5py.File(data_path + '/audio_test.h5', 'r')
        audio_test = h5f['d1'][:]
        h5f.close()
        h5f = h5py.File(data_path + '/video_test.h5', 'r')
        video_test = h5f['d1'][:]
        h5f.close()
        h5f = h5py.File(data_path + '/text_test_emb.h5', 'r')
        text_test = h5f['d1'][:]
        h5f.close()
        # load y
        h5f = h5py.File(data_path + '/y_train.h5', 'r')
        y_train = h5f['d1'][:]
        h5f.close()
        h5f = h5py.File(data_path + '/y_valid.h5', 'r')
        y_valid = h5f['d1'][:]
        h5f.close()
        h5f = h5py.File(data_path + '/y_test.h5', 'r')
        y_test = h5f['d1'][:]
        h5f.close()
        d_l, d_a, d_v = 300, 74, 35
        time_step = 20
        input_dims = (d_a, d_v, d_l)
        #  drop data
        if noise_type != None:
            if noise_type == 'random':
                audio_train = random_drop(audio_train, p=p)
                video_train = random_drop(video_train, p=p)
                text_train = random_drop(text_train, p=p)
            elif noise_type == 'structured':
                audio_train = structured_drop(audio_train, p=p)
                video_train = structured_drop(video_train, p=p)
                text_train = structured_drop(text_train, p=p)
        train_set = LoadDataSet(audio_train, video_train, text_train, y_train, is_time=is_time)
        valid_set = LoadDataSet(audio_valid, video_valid, text_valid, y_valid, is_time=is_time)
        test_set = LoadDataSet(audio_test, video_test, text_test, y_test, is_time=is_time)
        if is_time:
            input_dims = (d_a, d_v, d_l, time_step)
    return train_set, valid_set, test_set, input_dims

# a class for selecting parameters from the given search range
class ParamSelecter(object):
    def __init__(self, param_lists):
        self.param_lists = param_lists
        self.n_feature = len(param_lists)
        self.id = 0
        self.list_len = []
        for param_list in param_lists:
            self.list_len.append(len(param_list))
        self.list_len.reverse()
        self.len_multi = [1]
        for l in self.list_len:
            self.len_multi.append(self.len_multi[-1]*l)
        self.len_multi = self.len_multi[1:]
        self.total_settings = self.len_multi[-1]

    def get_params(self):
        id_list = []
        id_list.append(self.id % self.len_multi[0])
        for i, multi_id in enumerate(self.len_multi[1:]):
            id_list.append(int(self.id / self.len_multi[i]) % self.list_len[i+1])
        id_list.reverse()
        output_list = []
        for i in range(self.n_feature):
            output_list.append(self.param_lists[i][id_list[i]])
        self.id += 1
        return output_list


def total(params):
    settings = 1
    for k, v in params.items():
        settings *= len(v)
    return settings


# load_data(dataset='mosi')