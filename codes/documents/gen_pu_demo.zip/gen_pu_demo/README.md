## GenPU
Code for "Generative Adversarial Positive-Unlabelled Learning"

## Prerequisites
Linux or OSX
Python 3.5
PyTorch
Numpy
Pickle


## Step 1 train a generator model
# folder 'logs/xxx_dataset/pun': the log contains the training details
# folder 'models/xxx_dataset/pun': the resulting positive and negative generator models
# folder 'samples/xxx_dataset/pun': the resulting samples generated from generator

'python3 pun_demo_main.py'

## Step 2 train a standard PN classifier using the positive and negative generators from a specific epoch of step 1
# folder 'logs/xxx_dataset/gpn': the log contains the training details
# folder 'models/xxx_dataset/gpn': the resulting PN classifier model
# folder 'samples/xxx_dataset/gpn': the resulting samples generated from generator of a specific epoch

'python3 gpn_classifier.py'

