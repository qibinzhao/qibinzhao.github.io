import h5py
import numpy as np
from torch.utils.data import Dataset
import json
import os


# a class for selecting parameters from the given searching range
class ParamSelecter(object):
    def __init__(self, param_lists):
        self.param_lists = param_lists
        self.n_feature = len(param_lists)
        self.id = 0
        self.list_len = []
        for param_list in param_lists:
            self.list_len.append(len(param_list))
        self.list_len.reverse()
        self.len_multi = [1]
        for l in self.list_len:
            self.len_multi.append(self.len_multi[-1]*l)
        self.len_multi = self.len_multi[1:]
        self.total_settings = self.len_multi[-1]

    def get_params(self):
        id_list = []
        id_list.append(self.id % self.len_multi[0])
        for i, multi_id in enumerate(self.len_multi[1:]):
            id_list.append(int(self.id / self.len_multi[i]) % self.list_len[i+1])
        id_list.reverse()
        output_list = []
        for i in range(self.n_feature):
            output_list.append(self.param_lists[i][id_list[i]])
        self.id += 1
        return output_list


# calculate the possible settings for the given searching range
def total(params):
    settings = 1
    for k, v in params.items():
        settings *= len(v)
    return settings


# function to info all metrics
def display(mae, corr, multi_acc, bi_acc, f1):
    print("MAE on test set is {}".format(mae))
    print("Correlation w.r.t human evaluation on test set is {}".format(corr))
    print("Multiclass accuracy on test set is {}".format(multi_acc))
    print("Binary accuracy on test set is {}".format(bi_acc))
    print("F1-score on test set is {}".format(f1))


# obtain settings we use
def get_repro_params():

    mosi_random = {
        'epochs': 200, 'patience': 20, 'output_dim': 1, 'cuda': True, 'seed': 0, 'dataset': 'mosi',
        'noise_type': 'random', 'is_reg': True, 'time_window': 3, 'stride': 1, 'ahid': 8, 'vhid': 16,
        'thid': 128, 'adr': 0.5, 'vdr': 0.5, 'tdr': 0.1, 'lr': 0.003, 'factor_lr': 0.003, 'bd': 32,
        'batch_sz': 4, 'decay': 0.0, 'norm_decay': 0.0001}

    mosi_structured = {
        'epochs': 200, 'patience': 20, 'output_dim': 1, 'cuda': True, 'seed': 0, 'dataset': 'mosi',
        'noise_type': 'structured', 'is_reg': True, 'time_window': 2, 'stride': 1, 'ahid': 8, 'vhid': 4,
        'thid': 128, 'adr': 0.3, 'vdr': 0.3, 'tdr': 0, 'lr': 0.003, 'factor_lr': 0.003, 'bd': 16,
        'batch_sz': 4, 'decay': 0.001, 'norm_decay': 0.01}

    mosei_random = {
        'epochs': 200, 'patience': 20, 'output_dim': 1, 'cuda': True, 'seed': 0, 'dataset': 'mosei',
        'noise_type': 'random', 'is_reg': True, 'time_window': 4, 'stride': 1, 'ahid': 8, 'vhid': 4,
        'thid': 128, 'adr': 0, 'vdr': 0.1, 'tdr': 0, 'lr': 0.003, 'factor_lr': 0.001, 'bd': 24,
        'batch_sz': 4, 'decay': 0.0, 'norm_decay': 0.001}

    mosei_structured = {
        'epochs': 200, 'patience': 20, 'output_dim': 1, 'cuda': True, 'seed': 0, 'dataset': 'mosei',
        'noise_type': 'structured', 'is_reg': True, 'time_window': 4, 'stride': 1, 'ahid': 16, 'vhid': 4,
        'thid': 64, 'adr': 0, 'vdr': 0.5, 'tdr': 0.3, 'lr': 0.0003, 'factor_lr': 0.001, 'bd': 32,
        'batch_sz': 128, 'decay': 0.0, 'norm_decay': 0.0001}

    with open(os.path.join(os.getcwd(), "settings/ours/mosi_random.json"), "w") as f:
        json.dump(mosi_random, f, indent=2, sort_keys=True, ensure_ascii=False)

    with open(os.path.join(os.getcwd(), "settings/ours/mosi_structured.json"), "w") as f:
        json.dump(mosi_structured, f, indent=2, sort_keys=True, ensure_ascii=False)

    with open(os.path.join(os.getcwd(), "settings/ours/mosei_random.json"), "w") as f:
        json.dump(mosei_random, f, indent=2, sort_keys=True, ensure_ascii=False)

    with open(os.path.join(os.getcwd(), "settings/ours/mosei_structured.json"), "w") as f:
        json.dump(mosei_structured, f, indent=2, sort_keys=True, ensure_ascii=False)


# Dataset for multi-modal sentiment analysis data
class LoadDataSet(Dataset):
    def __init__(self, audio, visual, text, labels):
        self.audio = audio
        self.visual = visual
        self.text = text
        self.labels = labels

    def __getitem__(self, idx):
        return [self.audio[idx, :, :], self.visual[idx, :, :], self.text[idx, :, :], self.labels[idx]]

    def __len__(self):
        return self.audio.shape[0]


# random drop for raw data
def random_drop(x, p, seed=0):
    np.random.seed(seed)
    p = max(0, min(1, p))
    batch_size = x.shape[0]
    time_step = x.shape[1]
    new_x = x.copy()
    try:
        new_x = new_x.view(batch_size, -1)
    except:
        new_x = np.reshape(new_x, newshape=[batch_size, -1])
    num_feature = new_x.shape[1]
    for i in range(batch_size):
        for j in range(num_feature):
            r = np.random.random()
            if r < p:
                new_x[i, j] = 0
    try:
        new_x = new_x.view(batch_size, time_step, -1)
    except:
        new_x = np.reshape(new_x, newshape=[batch_size, time_step, -1])
    return new_x


# structured drop for raw data
def structured_drop(x, p, seed=0):
    np.random.seed(seed)
    p = max(0, min(1, p))
    time_step = x.shape[1]
    new_x = x.copy()
    for t in range(time_step):
        r = np.random.random()
        if r < p:
            # drop the whole entries for this time step
            new_x[:, t, :] = 0
    return new_x


# load CMU-MOSI
def load_mosi(data_path, noise_type=None, p=0, seed=0):
    data_path += '/mosi'
    # load raw data
    h5f = h5py.File(data_path + '/X_train.h5', 'r')
    x_train = h5f['data'][:]
    h5f.close()
    h5f = h5py.File(data_path + '/y_train.h5', 'r')
    y_train = h5f['data'][:]
    h5f.close()
    h5f = h5py.File(data_path + '/X_valid.h5', 'r')
    x_valid = h5f['data'][:]
    h5f.close()
    h5f = h5py.File(data_path + '/y_valid.h5', 'r')
    y_valid = h5f['data'][:]
    h5f.close()
    h5f = h5py.File(data_path + '/X_test.h5', 'r')
    x_test = h5f['data'][:]
    h5f.close()
    h5f = h5py.File(data_path + '/y_test.h5', 'r')
    y_test = h5f['data'][:]
    h5f.close()
    d_l, d_a, d_v = 300, 5, 20
    time_step = 20
    audio_train = x_train[:, :, d_l:d_l + d_a]
    video_train = x_train[:, :, d_l + d_a:]
    text_train = x_train[:, :, :d_l]
    # drop data
    if noise_type != None:
        if noise_type == 'random':
            audio_train = random_drop(audio_train, p=p, seed=seed)
            video_train = random_drop(video_train, p=p, seed=seed)
            text_train = random_drop(text_train, p=p, seed=seed)
        elif noise_type == 'structured':
            # seed = [seed, seed + 1, seed + 1] at first
            audio_train = structured_drop(audio_train, p=p, seed=seed)
            video_train = structured_drop(video_train, p=p, seed=seed + 1)
            text_train = structured_drop(text_train, p=p, seed=seed + 2)
    train_set = LoadDataSet(audio_train, video_train, text_train, y_train)
    valid_set = LoadDataSet(x_valid[:, :, d_l:d_l + d_a], x_valid[:, :, d_l + d_a:], x_valid[:, :, :d_l], y_valid)
    test_set = LoadDataSet(x_test[:, :, d_l:d_l + d_a], x_test[:, :, d_l + d_a:], x_test[:, :, :d_l], y_test)
    input_dims = (d_a, d_v, d_l, time_step)
    return train_set, valid_set, test_set, input_dims


# load CMU-MOSEI
def load_mosei(data_path, noise_type=None, p=0, seed=0):
    data_path += '/mosei'
    # load train
    h5f = h5py.File(data_path + '/audio_train.h5', 'r')
    audio_train = h5f['d1'][:]
    h5f.close()
    h5f = h5py.File(data_path + '/video_train.h5', 'r')
    video_train = h5f['d1'][:]
    h5f.close()
    h5f = h5py.File(data_path + '/text_train_emb.h5', 'r')
    text_train = h5f['d1'][:]
    h5f.close()
    # load valid
    h5f = h5py.File(data_path + '/audio_valid.h5', 'r')
    audio_valid = h5f['d1'][:]
    h5f.close()
    h5f = h5py.File(data_path + '/video_valid.h5', 'r')
    video_valid = h5f['d1'][:]
    h5f.close()
    h5f = h5py.File(data_path + '/text_valid_emb.h5', 'r')
    text_valid = h5f['d1'][:]
    h5f.close()
    # load test
    h5f = h5py.File(data_path + '/audio_test.h5', 'r')
    audio_test = h5f['d1'][:]
    h5f.close()
    h5f = h5py.File(data_path + '/video_test.h5', 'r')
    video_test = h5f['d1'][:]
    h5f.close()
    h5f = h5py.File(data_path + '/text_test_emb.h5', 'r')
    text_test = h5f['d1'][:]
    h5f.close()
    # load y
    h5f = h5py.File(data_path + '/y_train.h5', 'r')
    y_train = h5f['d1'][:]
    h5f.close()
    h5f = h5py.File(data_path + '/y_valid.h5', 'r')
    y_valid = h5f['d1'][:]
    h5f.close()
    h5f = h5py.File(data_path + '/y_test.h5', 'r')
    y_test = h5f['d1'][:]
    h5f.close()
    d_l, d_a, d_v = 300, 74, 35
    time_step = 20
    #  drop data
    if noise_type != None:
        if noise_type == 'random':
            audio_train = random_drop(audio_train, p=p, seed=seed)
            video_train = random_drop(video_train, p=p, seed=seed)
            text_train = random_drop(text_train, p=p, seed=seed)
        elif noise_type == 'structured':
            audio_train = structured_drop(audio_train, p=p, seed=seed)
            video_train = structured_drop(video_train, p=p, seed=seed + 1)
            text_train = structured_drop(text_train, p=p, seed=seed + 2)
    train_set = LoadDataSet(audio_train, video_train, text_train, y_train)
    valid_set = LoadDataSet(audio_valid, video_valid, text_valid, y_valid)
    test_set = LoadDataSet(audio_test, video_test, text_test, y_test)
    input_dims = (d_a, d_v, d_l, time_step)
    return train_set, valid_set, test_set, input_dims


# load mosi/mosei from data_path, is_time means whether to retain the dimension of time or not.
def load_data(data_path=os.path.join(os.getcwd(), 'data'), dataset='mosi', noise_type=None, p=0, seed=0):
    if dataset == 'mosi':
        return load_mosi(data_path, noise_type, p, seed)
    elif dataset == 'mosei':
        return load_mosei(data_path, noise_type, p, seed)
