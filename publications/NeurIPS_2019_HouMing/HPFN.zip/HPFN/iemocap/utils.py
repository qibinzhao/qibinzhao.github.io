from torch.utils.data import Dataset
import pickle as pickle

AUDIO = 'covarep'
VISUAL = 'facet'
TEXT = 'glove'
LABEL = 'label'


def total(params):
    """
    count the total number of hyper-parameter settings
    """
    settings = 1
    for k, v in params.items():
        settings *= len(v)
    return settings


def load_iemocap(data_path, emotion):
    """
    load IEMOCAP data
    """
    # parse the input args
    iemocap_data = pickle.load(open(data_path + "iemocap.pkl", 'rb'), encoding='latin1')

    iemocap_train = iemocap_data[emotion]['train']
    train_audio = iemocap_train[AUDIO]
    train_visual = iemocap_train[VISUAL]
    train_text = iemocap_train[TEXT]
    train_labels = iemocap_train[LABEL]

    iemocap_valid = iemocap_data[emotion]['valid']
    valid_audio = iemocap_valid[AUDIO]
    valid_visual = iemocap_valid[VISUAL]
    valid_text = iemocap_valid[TEXT]
    valid_labels = iemocap_valid[LABEL]

    iemocap_test = iemocap_data[emotion]['test']
    test_audio = iemocap_test[AUDIO]
    test_visual = iemocap_test[VISUAL]
    test_text = iemocap_test[TEXT]
    test_labels = iemocap_test[LABEL]

    # instantiate the dataset objects
    train_set = IEMOCAP(train_audio, train_visual, train_text, train_labels)
    valid_set = IEMOCAP(valid_audio, valid_visual, valid_text, valid_labels)
    test_set = IEMOCAP(test_audio, test_visual, test_text, test_labels)

    audio_dim = train_set[0][0].shape[0]
    print("Audio feature dimension is: {}".format(audio_dim))
    visual_dim = train_set[0][1].shape[0]
    print("Visual feature dimension is: {}".format(visual_dim))
    text_dim = train_set[0][2].shape[1]
    print("Text feature dimension is: {}".format(text_dim))
    input_dims = (audio_dim, visual_dim, text_dim)

    # remove possible NaN values
    train_set.visual[train_set.visual != train_set.visual] = 0
    valid_set.visual[valid_set.visual != valid_set.visual] = 0
    test_set.visual[test_set.visual != test_set.visual] = 0

    train_set.audio[train_set.audio != train_set.audio] = 0
    valid_set.audio[valid_set.audio != valid_set.audio] = 0
    test_set.audio[test_set.audio != test_set.audio] = 0
    return train_set, valid_set, test_set, input_dims


class IEMOCAP(Dataset):
    """
    PyTorch Dataset for IEMOCAP
    """
    def __init__(self, audio, visual, text, labels):
        self.audio = audio
        self.visual = visual
        self.text = text
        self.labels = labels

    def __getitem__(self, idx):
        return [self.audio[idx, :], self.visual[idx, :], self.text[idx, :, :], self.labels[idx]]

    def __len__(self):
        return self.audio.shape[0]
