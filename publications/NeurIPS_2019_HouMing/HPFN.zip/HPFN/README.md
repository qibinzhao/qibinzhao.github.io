# High-order Polynomial Fusion Network (HFPN)

This is the repository for "Deep Multimodal Multilinear Fusion with High-order Polynomial Pooling", Hou and Tang, et. al. NIPS 2019.

## Dependencies

Python 3.7

PyTorch 1.4.0

sklearn

numpy


## Data for Demo

The processed data for the experiments (CMU-MOSI, IEMOCAP) can be downloaded here:

https://drive.google.com/open?id=1CixSaw3dpHESNG0CaCJV6KutdlANP_cr

To run the code, you should download the pickled datasets and put them in the `data` directory.

## Model for Demo
In this demo we construct a particular two-layer HPFN model using the following architecture:

the hidden layer [PTP1(a, v), PTP2(v, l), PTP3(a, l)]

the output layer [PTP(PTP1, PTP2, PTP3)]

the script `iemocap\model_iemocap_l2.py` for non-temporal HPFN model.

the script `mosi\model_mosi_no_l2.py` for temporal HPFN model with no overlapping in time dimension.


## Model Training

To run the code for experiments (grid search), use the scripts `train_xxx_l2.py`. They have some commandline arguments as listed here:

________________________________

For non-temporal model:

`emotion`: (exclusive for IEMOCAP) specifies which emotion category you want to train the model to predict. Can be 'happy', 'sad', 'angry', 'neutral'.

`poly_order`: the list specifies the polynomial order of the each layer.

`poly_norm`: the polynomial normalization, set 0 to disable. 

`euclid_norm`: the l2 normalization, set 0 to disable. 

`init_modal_len`: the number of modalities of the input layer. 

`modal_wins`: the list specifies the modality window sizes from the input layer to the last hidden layer. 

`modal_pads`: the list specifies the modality padding sizes from the input layer to the last hidden layer. 

`epochs`: the number of maximum epochs in training. Note that the actual number of epochs will be determined also by the `patience` argument.

`patience`: the number of epochs the model is allowed to fluctuate without improvements on the validation set during training. E.g when the patience is set to 5 and the model's performance fluctuates without exceeding previous best for 5 epochs consecutively, the training stops.

`output_dim`: for regression tasks it is usually set as 1. But for IEMOCAP can be viewed as a classification task and it can be set to multiple dimensions.

`run_id`: an user-specified unique ID to ensure that saved results/models don't override each other.

`signiture`: optional string for comment.

`data_path`: the path to the data directory. Defaults to './data', but if you prefer storing the data else where you can change this.

`model_path`: the path to the directory where the models that are trained are saved.

`output_path`: the path to the directory where the grid search results are saved.

For temporal model:

`init_time_len`: the number of time steps of the input layer. 

`time_wins`: the list that specifies the time window sizes from the input layer to the last hidden layer. 

`time_pads`: the list that specifies the time pad sizes from the input layer to the last hidden layer. 

_____________________________

