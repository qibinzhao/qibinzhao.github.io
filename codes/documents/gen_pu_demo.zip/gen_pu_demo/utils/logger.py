import os
import collections
import pickle as pickle
import numpy as np
# import matplotlib.pyplot as plt


class Logger(object):
    def __init__(self, log_path):
        self.since_start = collections.defaultdict(lambda: {})
        self.since_last_flush = collections.defaultdict(lambda: {})
        self.log_iter = 0
        self.log_path = log_path
        self.make_log_dir()

    def make_log_dir(self):
        if not os.path.exists(self.log_path):
            os.makedirs(self.log_path)

    def tick(self):
        self.log_iter += 1

    def plot(self, name, value):
        self.since_last_flush[name][self.log_iter] = value

    def flush(self, epoch):
        prints = []
        for name, vals in self.since_last_flush.items():
            prints.append('{}:{:.4f}'.format(name, np.mean(list(vals.values()))))
            self.since_start[name].update(vals)
            # x_vals = np.sort(list(self.since_start[name].keys()))
            # y_vals = [self.since_start[name][x] for x in x_vals]
            # plt.clf()
            # plt.plot(x_vals, y_vals)
            # plt.xlabel('iteration')
            # plt.ylabel(name)
            # plt.savefig(os.path.join(self.log_path, name) + '.png')
        print('[EPOCH {}]\t{}'.format(epoch, ' '.join(prints)))
        self.since_last_flush.clear()

        with open(os.path.join(self.log_path, 'log.pkl'), 'wb') as f:
            pickle.dump(dict(self.since_start), f, protocol=pickle.HIGHEST_PROTOCOL)
