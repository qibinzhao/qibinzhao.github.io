from TPFN import TPFN
from utils import load_data
from torch.utils.data import DataLoader
import os
import torch
import random
import torch.nn as nn
import torch.optim as optim
import numpy as np
import csv
from test import test


def train(options):
    DTYPE = torch.FloatTensor
    # parse the input args
    epochs = options['epochs']
    data_path = options['data_path']
    model_path = options['model_path']
    output_path = options['output_path']
    patience = options['patience']
    output_dim = options['output_dim']
    dataset = options['dataset']
    noise_type = options['noise_type']
    k = options['time_window']
    stride = options['stride']
    # whether to use rank regularization
    is_reg = options['is_reg']
    seed = options['seed']
    ahid = options['ahid']
    vhid = options['vhid']
    thid = options['thid']
    adr = options['adr']
    vdr = options['vdr']
    tdr = options['tdr']
    lr = options['lr']
    factor_lr = options['factor_lr']
    bd = options['bd']
    batch_sz = options['batch_sz']
    decay = options['decay']
    norm_decay = options['norm_decay']
    is_cuda = options['cuda']
    p = [0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]
    random.seed(seed)
    torch.random.manual_seed(seed)
    print("Training on {} for {} drop task".format(dataset, noise_type))
    print("Training initializing...}")

    # # select settings
    # audio_hidden = [8, 16]
    # video_hidden = [4, 8, 16]
    # text_hidden = [64, 128]
    # audio_dropout = [0., 0.1, 0.3, 0.5]
    # video_dropout = [0., 0.1, 0.3, 0.5]
    # text_dropout = [0., 0.1, 0.3, 0.5]
    # learning_rate = [0.0003, 0.001, 0.003]
    # factor_lr = [0.0003, 0.001, 0.003]
    # bd = [4, 8, 12, 16, 24, 32]
    # batch_size = [4, 16, 64, 128]
    # weight_decay = [0., 0.001, 0.01]
    # norm_decay = [0.0, 0.0001, 0.001, 0.003, 0.01]
    # if is_reg: norm_decay = [0.0001, 0.001, 0.003, 0.01]
    # norm_decay = [0.0, 0.0001, 0.001, 0.003, 0.01]
    # ps = ParamSelecter([audio_hidden, video_hidden, text_hidden, audio_dropout, video_dropout, text_dropout,
    #                     learning_rate, factor_lr, bd, batch_size, weight_decay, norm_decay])
    # params_list = [ps.get_params() for i in range(ps.total_settings)]
    # random.shuffle(params_list)
    # for params in params_list:
    #     ahid = params[0]
    #     vhid = params[1]
    #     thid = params[2]
    #     adr = params[3]
    #     vdr = params[4]
    #     tdr = params[5]
    #     lr = params[6]
    #     factor_lr = params[7]
    #     bd = params[8]
    #     batch_sz = params[9]
    #     decay = params[10]
    #     norm_decay = params[11]

    for pi in p:
        # prepare the paths for storing models and outputs
        curr_out = os.path.join(output_path, "results_TPFN_{}_{}_{}.csv".format(dataset, noise_type, pi))
        curr_model = os.path.join(model_path, "model_TPFN_{}_{}_{}.pt".format(dataset, noise_type, pi))
        if not os.path.exists(curr_out):
            with open(curr_out, 'w+') as o:
                writer = csv.writer(o)
                writer.writerow(
                    ["audio_hidden", "video_hidden", 'text_hidden', 'audio_dropout', 'video_dropout', 'text_dropout',
                     'lr', 'factor_lr', 'bd', 'batch_size', 'weight_decay', 'norm_decay', 'acc'])
        print("Temp location for models: {}".format(curr_model))
        print("Grid search results are in: {}".format(curr_out))

        # load data that dropped with missing percentage p
        train_set, valid_set, test_set, input_dims = load_data(data_path, noise_type=noise_type, p=pi, dataset=dataset, seed=seed)
        model = TPFN(input_dims, (ahid, vhid, thid), (adr, vdr, tdr), output_dim, bd, time_window=k, stride=stride, is_cuda=is_cuda)
        if options['cuda']:
            model = model.cuda()
            DTYPE = torch.cuda.FloatTensor
        print("Model initialized")

        # define MAE loss
        criterion = nn.L1Loss(size_average=False)
        factors = list(model.parameters())[13:]
        other = list(model.parameters())[1:13]
        # use additional learning rate specific to the CP factors
        optimizer = optim.Adam([{"params": factors, "lr": factor_lr}, {"params": other, "lr": lr}], weight_decay=decay)

        # setup training
        complete = True
        min_valid_loss = float('Inf')
        train_iterator = DataLoader(train_set, batch_size=batch_sz, num_workers=4, shuffle=True)
        valid_iterator = DataLoader(valid_set, batch_size=len(valid_set), num_workers=4, shuffle=True)
        curr_patience = patience

        for e in range(epochs):
            # train on training set
            complete = True
            model.train()
            model.zero_grad()
            avg_train_loss = 0.0
            for batch in train_iterator:
                model.zero_grad()
                x = batch[:-1]
                x_a = torch.Tensor(x[0].float()).squeeze().type(DTYPE)
                x_v = torch.Tensor(x[1].float()).squeeze().type(DTYPE)
                x_t = torch.Tensor(x[2].float()).type(DTYPE)
                y = torch.Tensor(batch[-1].view(-1, output_dim).float()).type(DTYPE)
                output = model(x_a, x_v, x_t)
                loss = criterion(output, y)
                if is_reg:
                    loss += norm_decay*model.norm
                loss.backward()
                avg_loss = loss.data.item()
                avg_train_loss += avg_loss / len(train_set)
                optimizer.step()
            print("Epoch {} complete! Average Training loss: {}".format(e, avg_train_loss))
            # terminate if run into NaN
            if np.isnan(avg_train_loss):
                print("Training got into NaN values...\n\n")
                complete = False
                break

            # evaluate on valid set
            model.eval()
            for batch in valid_iterator:
                x = batch[:-1]
                x_a = torch.Tensor(x[0].float()).squeeze().type(DTYPE)
                x_v = torch.Tensor(x[1].float()).squeeze().type(DTYPE)
                x_t = torch.Tensor(x[2].float()).type(DTYPE)
                y = torch.Tensor(batch[-1].view(-1, output_dim).float()).type(DTYPE)
                output = model(x_a, x_v, x_t)
                valid_loss = criterion(output, y)
                avg_valid_loss = valid_loss.data.item()
            y = y.cpu().data.numpy().reshape(-1, output_dim)
            if np.isnan(avg_valid_loss):
                print("Training got into NaN values...\n\n")
                complete = False
                break
            avg_valid_loss = avg_valid_loss / len(valid_set)
            print("Validation loss is: {}".format(avg_valid_loss))
            if (avg_valid_loss < min_valid_loss):
                curr_patience = patience
                min_valid_loss = avg_valid_loss
                torch.save(model, curr_model)
                print("Found new best model, saving to disk...")
            else:
                curr_patience -= 1
            if curr_patience <= 0:
                # terminate the training process if valid loss fail to refresh over patience
                break
            print("\n\n")

        # test and record
        if complete:
            test(curr_model, test_set, output_dim=output_dim, is_cuda=options['cuda'], output_path=curr_out,
                 results=[ahid, vhid, thid, adr, vdr, tdr, lr, factor_lr, bd, batch_sz, decay, norm_decay])