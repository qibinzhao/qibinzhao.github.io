import pickle


with open('/gen_pu/pr0.02/pw0.2-puw1.0-nw5.0-nuw1.0/pun_gen/ep1400/log.pkl', 'rb') as handle:
    d = pickle.load(handle)
    vl = list(d['gpn_accuracy'].values())
    m = max(vl)
    print(m)
    count = 0
    for i in range(len(vl)):
        if vl[i] >= 98.0:
            count += 1
    print(count)



