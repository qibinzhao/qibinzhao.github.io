clc; clear all; close all;
%% NOTE
% This is a demo to show the recovery accuracy of the components by
% Reshuffled-TD. In this demo, we attempt to recover the latent components
% from synthetic data, and a figure with two sub-plots will appear
% after runing. The left sub-plot shows the change of the objective
% function in each iteration, and the right sub-plot shows a fragment of the
% orignal and recovered components for example. The caption of the figure gives the
% tSIR and SIR performance of the first components for current run.
%% Parameters
global Sz
N = 2; % number of the components
Sz = [64, 64]; % shape of the original data
Rk = 2*ones(1,N); % rank of two components
sigma = [1,1]; % weights on each components
%% Component Generation
for i = 1 : N
    U_tmp = orth(randn(Sz(1),Rk(i)));
    V_tmp = orth(randn(Sz(2),Rk(i)));
    A{i} = U_tmp*V_tmp';
end
%% Reshuffling Op. Generation
global ord
for i = 1 : N
    ord{i} = randperm(length(A{i}(:)))';
    b{i} = sigma(i)*A{i}(ord{i});
end
%% Observation Generation
x = 0;
for i = 1 : N
    x = x + b{i};
end
%% Decomposition -- Reshuffled-TD
R = {@R1, @R2};
Ri = {@Ri1, @Ri2};
% R = {@R1, @R2, @R3}; % for three components
% Ri = {@Ri1, @Ri2, @Ri3}; % for three components
lambda = {1,1};
mu = 1;
ro = 1.01;
MaxIter = 10000;
tol = 1e-5;
tic
[ a_esti,f_esti ] = ReshuffledTD( x, R, Ri,lambda,mu,ro,MaxIter,tol,0);
% [ a_esti,f_esti ] = RsPCA_IALM_A_IHT( x, R, Ri,lambda,mu,ro,MaxIter,tol,0,Rk+20);
toc
%% evaluation
% Method 1 -- Overall SIR
SIR = 10*log10(norm(cell2mat(b),'fro')^2/norm(cell2mat(b)- ...
    cell2mat(a_esti(1:N)))^2);
% Method 2 -- 1st-component SIR
SIR1 = 10*log10(norm(cell2mat(b(1)),'fro')^2/norm(cell2mat(b(1))- ...
    cell2mat(a_esti(1)))^2);
disp('==========================================')
disp(['[*] The overall SIR equals ' num2str(SIR)]);
disp(['[*] The 1st-comp. SIR equals ' num2str(SIR1)]);
disp('==========================================')
%% Visualization
% title('R2(b{2})')
figure;
subplot(1,2,1)
plot(10*log10(f_esti),'-k');
xlabel('Iteration');
ylabel('Objective Func.(dB)')
subplot(1,2,2)
plot(b{1}(1:min([length(b{1}), 10])),'-k'); hold on;
plot(a_esti{1}(1:min([length(a_esti{1}), 10])),'-*r'); hold off;
legend('Original','Recoved');
xlabel('Points');
ylabel('Amp')
set(gcf,'Position',[400,400,600,300])
suptitle([ 'tSIR = ' num2str(SIR) 'dB, SIR of the 1st comp. = ' num2str(SIR1) 'dB']);
%% Reshaping Operation
function y = R1(x)
global ord
global Sz
y(ord{1}) = x;
y = reshape(y,Sz);
end
function y = R2(x)
global ord
global Sz
y(ord{2}) = x;
y = reshape(y,Sz);
end
%% The following function is for the case of tree components
% function y = R3(x)
% global ord
% global Sz
% y(ord{3}) = x;
% y = reshape(y,Sz);
% end
%% inverse of Reshuffling Operation
function y = Ri1(X)
global ord
y = X(ord{1});
end
function y = Ri2(X)
global ord
y = X(ord{2});
end
%% The following function is for the case of tree components
% function y = Ri3(X)
% global ord
% y = X(ord{3});
% end





