from __future__ import print_function
from RAIDEN.TPFN import TPFN
from RAIDEN.utils import load_data, ParamSelecter
from torch.utils.data import DataLoader
from sklearn.metrics import accuracy_score, f1_score
import os
import argparse
import torch
import random
import torch.nn as nn
import torch.optim as optim
import numpy as np
import csv
    

# function to info all metrics
def display(mae, corr, multi_acc, bi_acc, f1):
    print("MAE on test set is {}".format(mae))
    print("Correlation w.r.t human evaluation on test set is {}".format(corr))
    print("Multiclass accuracy on test set is {}".format(multi_acc))
    print("Binary accuracy on test set is {}".format(bi_acc))
    print("F1-score on test set is {}".format(f1))

def main(options):
    DTYPE = torch.FloatTensor
    # parse the input args
    run_id = options['run_id']
    epochs = options['epochs']
    data_path = options['data_path']
    model_path = options['model_path']
    output_path = options['output_path']
    patience = options['patience']
    output_dim = options['output_dim']
    dataset = options['dataset']
    noise_type = options['noise_type']
    k = options['time_window']
    stride = options['stride']
    is_reg = options['is_reg'] # whether to use rank regularization
    seed = options['seed']
    p = [0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]

    print("Training initializing... Setup ID is: {}".format(run_id))

    # prepare the paths for storing models and outputs
    model_path = os.path.join(
        model_path, "model_TPFN_{}_{}_{}_k={}_stride={}.pt".format(dataset, run_id, noise_type, k, stride))
    output_path = os.path.join(
        output_path, "results_TPFN_{}_{}_{}_k={}_stride={}.csv".format(dataset, run_id, noise_type, k, stride))
    print("Temp location for models: {}".format(model_path))
    print("Grid search results are in: {}".format(output_path))

    #"""
    audio_hidden = [8, 16]
    video_hidden = [4, 8, 16]
    text_hidden = [64, 128]
    audio_dropout = [0., 0.1, 0.3, 0.5]
    video_dropout = [0., 0.1, 0.3, 0.5]
    text_dropout = [0., 0.1, 0.3, 0.5]
    learning_rate = [0.0003, 0.001, 0.003]
    factor_lr = [0.0003, 0.001, 0.003]
    bd = [4, 8, 12, 16, 24, 32]
    batch_size = [4, 16, 64, 128]
    weight_decay = [0., 0.001, 0.01]
    norm_decay = [0.0, 0.0001, 0.001, 0.003, 0.01]
    ps = ParamSelecter([audio_hidden, video_hidden, text_hidden, audio_dropout, video_dropout, text_dropout,
                        learning_rate, factor_lr, bd, batch_size, weight_decay, norm_decay])
    params_list = [ps.get_params() for i in range(ps.total_settings)]
    random.shuffle(params_list)
    #"""
    
    if not os.path.exists(output_path):
        with open(output_path, 'w+') as out:
            writer = csv.writer(out)
            writer.writerow(
                ["audio_hidden", "video_hidden", 'text_hidden', 'audio_dropout', 'video_dropout', 'text_dropout',
                 'lr', 'factor_lr', 'bd', 'batch_size', 'weight_decay', 'norm_decay', 
                 'acc0', 'acc1', 'acc2', 'acc3', 'acc4', 'acc5', 'acc6', 'acc7', 'acc8', 'acc9', 'acc'])
    
    # for params in params_list:
        """
        # select parameters
        print(params)
        ahid = params[0]
        vhid = params[1]
        thid = params[2]
        adr = params[3]
        vdr = params[4]
        tdr = params[5]
        lr = params[6]
        factor_lr = params[7]
        bd = params[8]
        batch_sz = params[9]
        decay = params[10]
        norm_decay = params[11]
        # """
    for i in range(1):
        # reproduct results on TPFN
        # """
        seed = 0
        if dataset == 'mosi':
            if noise_type == 'random':
                # MOSI_random
                k=3
                stride=1
                ahid = 8
                vhid = 16
                thid = 128
                adr = 0.5
                vdr = 0.5
                tdr = 0.1
                lr = 0.003
                factor_lr = 0.003
                bd = 32
                batch_sz = 4
                decay = 0.0
                norm_decay = 0.0001
            elif noise_type == 'structured':
                # MOSI_structured
                k=2
                stride=1
                ahid = 8
                vhid = 4
                thid = 128
                adr = 0.3
                vdr = 0.3
                tdr = 0.0
                lr = 0.003
                factor_lr = 0.003
                bd = 16
                batch_sz = 4
                decay = 0.001
                norm_decay = 0.01
        elif dataset == 'mosei':
            if noise_type == 'random':
                # MOSEI_random
                k=4
                stride=1
                ahid = 16
                vhid = 8
                thid = 64
                adr = 0.0
                vdr = 0.3
                tdr = 0.3
                lr = 0.003
                factor_lr = 0.001
                bd = 12
                batch_sz = 128
                decay = 0.001
                norm_decay = 0.0    
            elif noise_type == 'structured':
                # MOSEI_structured
                k=4
                stride=1
                ahid = 16
                vhid = 4
                thid = 64
                adr = 0.0
                vdr = 0.5
                tdr = 0.3
                lr = 0.0003
                factor_lr = 0.001
                bd = 32
                batch_sz = 128
                decay = 0.0
                norm_decay = 0.0001 
        # """

        
        random.seed(seed)
        torch.random.manual_seed(seed)
        
        acc = []
        for pi in p:
            # load data that dropped with missing percentage p
            train_set, valid_set, test_set, input_dims = load_data(data_path, is_time=True, noise_type=noise_type, p=pi, dataset=dataset)
            model = TPFN(input_dims, (ahid, vhid, thid), (adr, vdr, tdr), output_dim, bd, time_window=k, stride=stride)
            if options['cuda']:
                model = model.cuda()
                DTYPE = torch.cuda.FloatTensor
            print("Model initialized")
            # MAE for loss function
            criterion = nn.L1Loss(size_average=False)
            factors = list(model.parameters())[13:]
            other = list(model.parameters())[1:13]
            # use another learning rate specific to the CP factors
            optimizer = optim.Adam([{"params": factors, "lr": factor_lr}, {"params": other, "lr": lr}], weight_decay=decay)

            # setup training
            complete = True  # to load the best model if complete
            min_valid_loss = float('Inf')
            train_iterator = DataLoader(train_set, batch_size=batch_sz, num_workers=4, shuffle=True)
            valid_iterator = DataLoader(valid_set, batch_size=len(valid_set), num_workers=4, shuffle=True)
            test_iterator = DataLoader(test_set, batch_size=len(test_set), num_workers=4, shuffle=True)
            curr_patience = patience

            for e in range(epochs):
                model.train()
                model.zero_grad()
                avg_train_loss = 0.0
                for batch in train_iterator:
                    model.zero_grad()
                    x = batch[:-1]
                    x_a = torch.Tensor(x[0].float()).squeeze().type(DTYPE)
                    x_v = torch.Tensor(x[1].float()).squeeze().type(DTYPE)
                    x_t = torch.Tensor(x[2].float()).type(DTYPE)
                    y = torch.Tensor(batch[-1].view(-1, output_dim).float()).type(DTYPE)
                    output = model(x_a, x_v, x_t)
                    loss = criterion(output, y)
                    if is_reg:
                        loss += norm_decay*model.norm
                    loss.backward()
                    avg_loss = loss.item()
                    avg_train_loss += avg_loss / len(train_set)
                    optimizer.step()
                print("Epoch {} complete! Average Training loss: {}".format(e, avg_train_loss))
                # terminate the training process if run into NaN
                if np.isnan(avg_train_loss):
                    print("Training got into NaN values...\n\n")
                    complete = False
                    break

                model.eval()
                for batch in valid_iterator:
                    x = batch[:-1]
                    x_a = torch.Tensor(x[0].float()).squeeze().type(DTYPE)
                    x_v = torch.Tensor(x[1].float()).squeeze().type(DTYPE)
                    x_t = torch.Tensor(x[2].float()).type(DTYPE)
                    y = torch.Tensor(batch[-1].view(-1, output_dim).float()).type(DTYPE)
                    output = model(x_a, x_v, x_t)
                    valid_loss = criterion(output, y)
                    avg_valid_loss = valid_loss.item()
                y = y.cpu().data.numpy().reshape(-1, output_dim)
                if np.isnan(avg_valid_loss):
                    print("Training got into NaN values...\n\n")
                    complete = False
                    break
                avg_valid_loss = avg_valid_loss / len(valid_set)
                print("Validation loss is: {}".format(avg_valid_loss))
                if (avg_valid_loss < min_valid_loss):
                    curr_patience = patience
                    min_valid_loss = avg_valid_loss
                    torch.save(model, model_path)
                    print("Found new best model, saving to disk...")
                else:
                    curr_patience -= 1
                if (curr_patience <= 0) or (e > 25 and avg_train_loss > 1.3):
                    # terminate the training process if valid loss fail to refresh over patience times or training valid fail to decline
                    break
                print("\n\n")

            if complete:
                """
                # get the real matrix M to get rank
                best_model = torch.load(model_path)
                best_model.eval()
                train_iterator = DataLoader(train_set, batch_size=len(train_set), num_workers=4, shuffle=True)
                for batch in train_iterator:
                    x = batch[:-1]
                    x_a = torch.Tensor(x[0].float()).squeeze().type(DTYPE)
                    x_v = torch.Tensor(x[1].float()).squeeze().type(DTYPE)
                    x_t = torch.Tensor(x[2].float()).type(DTYPE)
                    y = torch.Tensor(batch[-1].view(-1, output_dim).float()).type(DTYPE)
                    output_test = best_model(x_a, x_v, x_t, flag=True)
                    print(pi, torch.sum(x_v), torch.sum(output_test))
                    print(torch.sum(best_model.M))
                    np.save(noise_type + str(pi), best_model.M.detach().cpu().data)
                """
                # evalate on test set
                best_model = torch.load(model_path)
                best_model.eval()
                for batch in test_iterator:
                    x = batch[:-1]
                    x_a = torch.Tensor(x[0].float()).squeeze().type(DTYPE)
                    x_v = torch.Tensor(x[1].float()).squeeze().type(DTYPE)
                    x_t = torch.Tensor(x[2].float()).type(DTYPE)
                    y = torch.Tensor(batch[-1].view(-1, output_dim).float()).type(DTYPE)
                    output_test = best_model(x_a, x_v, x_t)
                    loss_test = criterion(output_test, y)
                output_test = output_test.cpu().data.numpy().reshape(-1, output_dim)
                y = y.cpu().data.numpy().reshape(-1, output_dim)
                # these are the needed metrics
                output_test = output_test.reshape((len(output_test),))
                y = y.reshape((len(y),))
                mae = np.mean(np.absolute(output_test - y))
                corr = round(np.corrcoef(output_test, y)[0][1], 5)
                multi_acc = round(sum(np.round(output_test) == np.round(y)) / float(len(y)), 5)
                true_label = (y >= 0)
                predicted_label = (output_test >= 0)
                bi_acc = accuracy_score(true_label, predicted_label)
                f1 = f1_score(true_label, predicted_label, average='weighted')
                display(mae, corr, multi_acc, bi_acc, f1)
                acc.append(bi_acc)
        with open(output_path, 'a+') as out:
            writer = csv.writer(out)
            # save the results of accuracy on binary classification
            writer.writerow([ahid, vhid, thid, adr, vdr, tdr, lr, factor_lr, bd, batch_sz, decay, norm_decay, *acc, np.mean(acc)])


if __name__ == "__main__":
    OPTIONS = argparse.ArgumentParser()    

    OPTIONS.add_argument('--run_id', dest='run_id', type=int, default=0)
    OPTIONS.add_argument('--epochs', dest='epochs', type=int, default=200)
    OPTIONS.add_argument('--patience', dest='patience', type=int, default=20)
    OPTIONS.add_argument('--output_dim', dest='output_dim', type=int, default=1)

    OPTIONS.add_argument('--cuda', dest='cuda', type=bool, default=True)
    OPTIONS.add_argument('--data_path', dest='data_path',
                         type=str, default='./data')
    OPTIONS.add_argument('--model_path', dest='model_path',
                         type=str, default='./models')
    OPTIONS.add_argument('--output_path', dest='output_path',
                         type=str, default='./results')
    
    OPTIONS.add_argument('-seed', dest='seed', type=int, default=0)
    OPTIONS.add_argument('-d', '--dataset', dest='dataset', type=str, default='mosi')
    OPTIONS.add_argument('-s', '--stride', dest='stride', type=int, default=1)
    OPTIONS.add_argument('-n', '--noise_type', dest='noise_type', type=str, default='random')
    OPTIONS.add_argument('-k', '--time_window', dest='time_window', type=int, default=3)
    OPTIONS.add_argument('-is_reg', dest='is_reg', type=bool, default=True)

    PARAMS = vars(OPTIONS.parse_args())

    main(PARAMS)
