import argparse
import os
import torch
import torch.nn as nn
import torch.nn.functional as functional
import torch.optim as optim
import torch.utils.data as data
import torchvision
import utils.logger as logger
import utils.data_wrapper as wrapper
import utils.func as func


class Gen(nn.Module):
    def __init__(self, z_dim=64, map_dim=64, image_size=28, leak=0.2, num_gpu=1):
        super(Gen, self).__init__()
        self.num_gpu = num_gpu
        self.fc = nn.Sequential(
            nn.Linear(z_dim, map_dim * 4), nn.LeakyReLU(leak),
            nn.Linear(map_dim * 4, map_dim * 4), nn.LeakyReLU(leak),
            nn.Linear(map_dim * 4, image_size * image_size), nn.Tanh())

    def forward(self, z):
        if isinstance(z.data, torch.cuda.FloatTensor) and self.num_gpu > 1:
            out = nn.parallel.data_parallel(self.fc, z, range(self.num_gpu))
        else:
            out = self.fc(z)
        return out


class MLP(nn.Module):
    def __init__(self, map_dim=64, image_size=28, leak=0.2, num_gpu=1):
        super(MLP, self).__init__()
        self.num_gpu = num_gpu
        self.fc = nn.Sequential(
            nn.Linear(image_size * image_size, map_dim * 4), nn.LeakyReLU(leak),
            nn.Linear(map_dim * 4, map_dim * 4), nn.LeakyReLU(leak),
            nn.Linear(map_dim * 4, 1), nn.Sigmoid())

    def forward(self, x):
        if isinstance(x.data, torch.cuda.FloatTensor) and self.num_gpu > 1:
            out = nn.parallel.data_parallel(self.fc, x, range(self.num_gpu))
        else:
            out = self.fc(x)
        return out.squeeze()


class MLP1(nn.Module):
    def __init__(self, map_dim=64, image_size=28, leak=0.2, num_gpu=1):
        super(MLP1, self).__init__()
        self.num_gpu = num_gpu
        self.fc = nn.Sequential(
            nn.Linear(image_size * image_size, map_dim * 8), nn.LeakyReLU(leak),
            nn.Linear(map_dim * 8, map_dim * 8), nn.LeakyReLU(leak),
            nn.Linear(map_dim * 8, map_dim * 4), nn.LeakyReLU(leak),
            nn.Linear(map_dim * 4, map_dim * 4), nn.LeakyReLU(leak),
            nn.Linear(map_dim * 4, 1), nn.Sigmoid())

    def forward(self, x):
        if isinstance(x.data, torch.cuda.FloatTensor) and self.num_gpu > 1:
            out = nn.parallel.data_parallel(self.fc, x, range(self.num_gpu))
        else:
            out = self.fc(x)
        return out.squeeze()


class GPN(object):
    def __init__(self, config):
        self.P_CLASS = config.P_CLASS
        self.N_CLASS = config.N_CLASS
        self.P_RATIO = config.P_RATIO
        self.CHANEL_DIM = config.CHANEL_DIM
        self.Z_DIM = config.Z_DIM
        self.MAP_DIM = config.MAP_DIM
        self.IMAGE_SIZE = config.IMAGE_SIZE
        self.LEAK = config.LEAK

        self.NUM_GPU = config.NUM_GPU
        self.ITERS = config.ITERS
        self.LR = config.LR
        self.BETA1 = config.BETA1
        self.BETA2 = config.BETA2

        self.IMAGE_SET = config.IMAGE_SET
        self.IMAGE_PATH = config.IMAGE_PATH
        self.NUM_IMAGES = config.NUM_IMAGES
        self.BATCH_SIZE = config.BATCH_SIZE
        self.WORKERS = config.WORKERS

        self.VERBOSE = config.VERBOSE
        self.TEST_STEP = config.TEST_STEP
        self.LOG_STEP = config.LOG_STEP
        self.LOG_PATH = config.LOG_PATH
        self.SAMPLE_PATH = config.SAMPLE_PATH
        self.MODEL_PATH = config.MODEL_PATH

        self.P_WEIGHT = config.P_WEIGHT
        self.PU_WEIGHT = config.PU_WEIGHT
        self.N_WEIGHT = config.N_WEIGHT
        self.NU_WEIGHT = config.NU_WEIGHT
        self.GEN_MODEL = config.GEN_MODEL
        self.P_GEN_PATH = None
        self.N_GEN_PATH = None
        self.P_GEN_EPOCH = config.P_GEN_EPOCH
        self.N_GEN_EPOCH = config.N_GEN_EPOCH
        self.make_sub_dir()

        self.test_loader = None
        self.get_loader()

        self.p_gen = None
        self.n_gen = None
        self.dis = None
        self.dis_optim = None
        self.build_model()

        self.train_logger = None
        self.test_logger = None
        self.create_logger()

    def make_sub_dir(self):
        sub_dir1 = '/{}/gpn'.format(self.IMAGE_SET)
        sub_dir2 = '/pc{}-nc{}'.format(self.P_CLASS, self.N_CLASS)
        sub_dir3 = '/pr{}'.format(self.P_RATIO)
        sub_dir4 = '/pw{}-puw{}-nw{}-nuw{}'.format(self.P_WEIGHT, self.PU_WEIGHT, self.N_WEIGHT, self.NU_WEIGHT)
        if self.GEN_MODEL == 'pun':
            sub_dir5 = '/pun_gen'
        else:
            sub_dir5 = '/pu_gen'
        sub_dir6 = '/ep{}'.format(self.P_GEN_EPOCH)
        sub_dir = sub_dir1 + sub_dir2 + sub_dir3 + sub_dir4 + sub_dir5 + sub_dir6

        if self.GEN_MODEL == 'pun':
            gen_sub_dir = '/{}/pun'.format(self.IMAGE_SET)
            gen_path = self.MODEL_PATH + gen_sub_dir + sub_dir2 + sub_dir3 + sub_dir4
            self.P_GEN_PATH = gen_path
            self.N_GEN_PATH = gen_path
        else:
            gen_sub_dir = '/{}/pu'.format(self.IMAGE_SET)
            p_gen_sub_dir = '/pw{}-puw{}'.format(self.P_WEIGHT, self.PU_WEIGHT)
            n_gen_sub_dir = '/nw{}-nuw{}'.format(self.N_WEIGHT, self.NU_WEIGHT)
            self.P_GEN_PATH = self.MODEL_PATH + gen_sub_dir + sub_dir2 + sub_dir3 + p_gen_sub_dir
            self.N_GEN_PATH = self.MODEL_PATH + gen_sub_dir + sub_dir2 + sub_dir3 + n_gen_sub_dir
        if not os.path.exists(self.P_GEN_PATH):
            ValueError('p_gen does not exist!')
        if not os.path.exists(self.N_GEN_PATH):
            ValueError('n_gen does not exist!')

        self.LOG_PATH += sub_dir
        self.MODEL_PATH += sub_dir
        self.SAMPLE_PATH += sub_dir
        if not os.path.exists(self.MODEL_PATH):
            os.makedirs(self.MODEL_PATH)
        if not os.path.exists(self.SAMPLE_PATH):
            os.makedirs(self.SAMPLE_PATH)

    def build_model(self):
        self.p_gen = Gen(z_dim=self.Z_DIM, map_dim=self.MAP_DIM, image_size=self.IMAGE_SIZE,
                         leak=self.LEAK, num_gpu=self.NUM_GPU)
        self.n_gen = Gen(z_dim=self.Z_DIM, map_dim=self.MAP_DIM, image_size=self.IMAGE_SIZE,
                         leak=self.LEAK, num_gpu=self.NUM_GPU)
        # load p_gen and n_gen
        p_gen_path = os.path.join(self.P_GEN_PATH, 'p_gen-%d.pkl' % self.P_GEN_EPOCH)
        self.p_gen.load_state_dict(torch.load(p_gen_path))
        n_gen_path = os.path.join(self.N_GEN_PATH, 'n_gen-%d.pkl' % self.N_GEN_EPOCH)
        self.n_gen.load_state_dict(torch.load(n_gen_path))
        # sample p_image and n_image
        if self.VERBOSE:
            z = torch.randn(self.BATCH_SIZE, self.Z_DIM)
            z_var = func.to_variable(z, volatile=True)
            p_fakes = self.p_gen(z_var)
            p_fakes = p_fakes.view(p_fakes.size(0), self.CHANEL_DIM, self.IMAGE_SIZE, self.IMAGE_SIZE)
            torchvision.utils.save_image(func.denormalize(p_fakes.data),
                                         os.path.join(self.SAMPLE_PATH, 'p_gen-%d.png' % self.P_GEN_EPOCH), nrow=20)
            n_fakes = self.n_gen(z_var)
            n_fakes = n_fakes.view(n_fakes.size(0), self.CHANEL_DIM, self.IMAGE_SIZE, self.IMAGE_SIZE)
            torchvision.utils.save_image(func.denormalize(n_fakes.data),
                                         os.path.join(self.SAMPLE_PATH, 'n_gen-%d.png' % self.N_GEN_EPOCH), nrow=20)
        self.dis = MLP1(map_dim=self.MAP_DIM, image_size=self.IMAGE_SIZE, leak=self.LEAK)
        if torch.cuda.is_available():
            self.p_gen.cuda()
            self.n_gen.cuda()
            self.dis.cuda()
        self.dis_optim = optim.Adam(self.dis.parameters(), lr=self.LR, betas=(self.BETA1, self.BETA2))

    def create_logger(self):
        self.train_logger = logger.Logger(self.LOG_PATH)
        self.test_logger = logger.Logger(self.LOG_PATH)

    def get_loader(self):
        test_set = wrapper.TestSetMNIST(image_path=self.IMAGE_PATH, image_size=self.IMAGE_SIZE,
                                        p_class=self.P_CLASS, n_class=self.N_CLASS)
        self.test_loader = data.DataLoader(dataset=test_set, batch_size=self.BATCH_SIZE,
                                           shuffle=True, num_workers=self.WORKERS, drop_last=True)

    def reset_grad(self):
        self.p_gen.zero_grad()
        self.n_gen.zero_grad()
        self.dis.zero_grad()

    def save_model(self, iteration):
        dis_path = os.path.join(self.MODEL_PATH, 'gpn_dis-%d.pkl' % iteration)
        torch.save(self.dis.state_dict(), dis_path)

    def train_model(self):
        # ========== train dis ==========
        for it in range(self.ITERS):
            self.reset_grad()
            # generate p_image and p_label
            pz = torch.randn(self.BATCH_SIZE, self.Z_DIM)
            pz_var = func.to_variable(pz)
            p_image = self.p_gen(pz_var)
            p_label = func.to_variable(torch.ones(self.BATCH_SIZE))
            # generate n_image and n_label
            nz = torch.randn(self.BATCH_SIZE, self.Z_DIM)
            nz_var = func.to_variable(nz)
            n_image = self.n_gen(nz_var)
            n_label = func.to_variable(torch.zeros(self.BATCH_SIZE))
            # train dis with p_images
            d_p = self.dis(p_image.detach())
            d_p_loss = functional.binary_cross_entropy(d_p, p_label)
            d_p_loss.backward()
            # train dis with n_images
            d_n = self.dis(n_image.detach())
            d_n_loss = functional.binary_cross_entropy(d_n, n_label)
            d_n_loss.backward()
            self.dis_optim.step()

            # write info
            if self.VERBOSE:
                self.train_logger.plot('d_p_loss', d_p_loss.cpu().data.numpy())
                self.train_logger.plot('d_n_loss', d_n_loss.cpu().data.numpy())
                self.train_logger.tick()
            # plot logs every plot step
            if self.VERBOSE and (it + 1) % self.LOG_STEP == 0:
                self.save_model(it + 1)
                self.train_logger.flush(it + 1)

            # ========== test dis ==========
            if (it + 1) % self.TEST_STEP == 0:
                self.dis.eval()
                correct = 0
                total = 0
                for image, label in self.test_loader:
                    image = image.view(self.BATCH_SIZE, -1)
                    label = label.type(torch.LongTensor)
                    image = func.to_variable(image)
                    label = func.to_variable(label)
                    output = self.dis(image)
                    output[output >= 0.5] = 1
                    output[output < 0.5] = 0
                    output = output.type(torch.LongTensor)
                    total += label.size(0)
                    correct += (func.to_data(output) == func.to_data(label)).sum()
                accuracy = 100 * correct / total
                # write info
                if self.VERBOSE:
                    self.test_logger.plot('gpn_accuracy', accuracy)
                    self.test_logger.tick()
                    self.test_logger.flush(it + 1)


def gpn_main(config):
    # create pn dis model
    gpn_dis = GPN(config)
    gpn_dis.train_model()


if __name__ == '__main__':
    # parameters settings same as pun_demo_main
    pc_list = [3]
    nc_list = [5]
    pr_list = [0.002]
    pw_list = [0.01]
    puw_list = [1.0]
    nw_list = [100.0]
    nuw_list = [1.0]
    # training a classifier base on which epoch's generator model
    ep_list = [1200]
    for pr in pr_list:
        for pc, nc in zip(pc_list, nc_list):
            for pw, puw, nw, nuw in zip(pw_list, puw_list, nw_list, nuw_list):
                for ep in ep_list:
                    print('pr[%.4f], pc[%d]-nc[%d], pw[%.2f]-puw[%.2f]-nw[%.2f]-nuw[%.2f], ep[%d]'
                          % (pr, pc, nc, pw, puw, nw, nuw, ep))
                    # set parameters for PN classifier
                    parser = argparse.ArgumentParser()
                    # model hyper-params
                    parser.add_argument('--P_CLASS', type=int, default=pc)
                    parser.add_argument('--N_CLASS', type=int, default=nc)
                    parser.add_argument('--P_RATIO', type=float, default=pr)
                    parser.add_argument('--CHANEL_DIM', type=int, default=1)
                    parser.add_argument('--Z_DIM', type=int, default=64)
                    parser.add_argument('--MAP_DIM', type=int, default=64)
                    parser.add_argument('--IMAGE_SIZE', type=int, default=28)
                    parser.add_argument('--LEAK', type=float, default=0.2)
                    # training hyper-params
                    parser.add_argument('--NUM_GPU', type=int, default=1)
                    parser.add_argument('--ITERS', type=int, default=20000)
                    parser.add_argument('--P_WEIGHT', type=float, default=pw)
                    parser.add_argument('--PU_WEIGHT', type=float, default=puw)
                    parser.add_argument('--N_WEIGHT', type=float, default=nw)
                    parser.add_argument('--NU_WEIGHT', type=float, default=nuw)
                    parser.add_argument('--LR', type=float, default=0.0003)
                    parser.add_argument('--BETA1', type=float, default=0.9)
                    parser.add_argument('--BETA2', type=float, default=0.999)
                    # misc
                    parser.add_argument('--IMAGE_SET', type=str, default='mnist')
                    parser.add_argument('--IMAGE_PATH', type=str, default='./data')
                    parser.add_argument('--NUM_IMAGES', type=int, default=5000)
                    parser.add_argument('--WORKERS', type=int, default=2)
                    parser.add_argument('--BATCH_SIZE', type=int, default=100)
                    parser.add_argument('--VERBOSE', type=bool, default=True)
                    parser.add_argument('--TEST_STEP', type=int, default=5)
                    parser.add_argument('--LOG_STEP', type=int, default=100)
                    parser.add_argument('--LOG_PATH', type=str, default='./logs')
                    parser.add_argument('--SAMPLE_PATH', type=str, default='./samples')
                    parser.add_argument('--MODEL_PATH', type=str, default='./models')
                    parser.add_argument('--GEN_MODEL', type=str, default='pun')
                    parser.add_argument('--P_GEN_EPOCH', type=int, default=ep)
                    parser.add_argument('--N_GEN_EPOCH', type=int, default=ep)
                    args = parser.parse_args()
                    # main
                    gpn_main(args)
