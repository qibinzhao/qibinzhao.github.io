function [ a, f_opt ] = ReshuffledTD(x_o, R,Ri, LAM, mu, ro, MaxIter, tol,debug)
%% NOTE
%  Reshuffled-TD is a method for convex tensor decomposition
% (CTD) via low-rankness of subspace of components. Specifically, we
% optimize f({a_1,...,a_L}) = \sum_i||R_i(a_i)||_*, s.t. x = \sum_i{}a_i.
% As algorithm,  the code is implemented by Inexact Augmented Lagrangian
% Multiplier (IALM) method.
% Input:
% x - data vector.
% R - cell. reshuffling operation.
% Ri -cell. inverse of reshuffling operation.
% LAM - cell. tuning parameters weighting the nuclear norm
% mu - parameters for ALM
% ro - parameters for ALM mu+ = mu*ro
% MaxIter - # of maximum iteration
% tol - tolerance
% Output
% a - a cell of estimated components where x = \sum_i{}a_i.
% f_opt - the history value of the objective function for each iteration.
%% default parameters
% mu_init = 1;
% ro_init = 1.01; % parameters for IALM
% MaxIter_init = 10000; % maximum iteration
% tol_init = 1e-7; % tolerance
%% Preprocessing
x_v = x_o(:); % vectorlize the observation
% L = length(x_v); % dimension of the input
N = length(R); % number of component
mean_x = mean(x_v);
std_x = std(x_v-mean_x);
x = ( x_v - mean_x )/std_x;
%% Init
for i = 1 : N
    a{i} = x/N;
end
w = sign(x);
%% Iteration
for i_loop =  1 : MaxIter
    f_opt(i_loop) = 0;
    %% update the components
    for i = 1 : N
        ind = 1:N;
        ind(i) = [];
        tmp = R{i}(x-sum(cell2mat(a(ind)),2)+1/mu*w);
%         tmp = reshape(x-sum(cell2mat(a(ind)),2)+1/mu*w,R{i});
        [ U, D, V ] = svd(tmp,'econ');
        D = diag(D);
        D = max(D-LAM{i}/mu,0);
        A = U*diag(D)*V';
        a{i} = Ri{i}(A);
        %% calculate the objective function
        f_opt(i_loop) = f_opt(i_loop) + LAM{i}*sum(D);
    end
    if (debug==1)
        subplot(2,N,1)
        plot(10*log10(f_opt));
        title('Cost')
        for i = 1 : N
            subplot(2,N,N+i)
            stem(svd(R{i}(a{i}))); 
            title(['Comp. ' num2str(i)]);
        end
        drawnow; 
%         pause(1);
    end
    %% update w
    w = w + mu*(x-sum(cell2mat(a(1:N)),2));
    %% update mu
    mu = mu*ro;
    %% Stopping criterion
    if ( i_loop == 1 )
        a_pre = a;
        disp (['# of Iter is ' num2str(i_loop) '. chg of esti is NaN.' ]);
    else
        f(i_loop - 1) = norm(cell2mat(a(1:N))-cell2mat(a_pre(1:N)),'fro')^2 ...
            /norm(cell2mat(a_pre(1:N)),'fro')^2;
        if ( f(i_loop - 1) < tol )
            for i = 1 : N
                a{i} = a{i}*std_x;
            end
            a{N+1} = mean_x;
            break;
        end
        a_pre = a;
        disp (['# of Iter is ' num2str(i_loop) '. chg of esti is ' num2str(f(i_loop-1)) '.' ]);
    end
end