import torch
from torch.autograd import Variable


def to_variable(x, volatile=False):
    if torch.cuda.is_available():
        x = x.cuda()
    return Variable(x, volatile=volatile)


def to_data(x):
    if torch.cuda.is_available():
        x = x.cpu()
    return x.data


def denormalize(x):
    out = (x + 1) / 2
    return out.clamp(0, 1)


def weight_init(m):
    class_name = m.__class__.__name__
    if class_name.find('Conv') != -1:
        m.weight.data.normal_(0.0, 0.02)
    elif class_name.find('BatchNorm') != -1:
        m.weight.data.normal_(1.0, 0.02)
        m.bias.data.fill_(0)




