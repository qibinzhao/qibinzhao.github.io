# ensemble p and n generators
import argparse
import os
import torch
import torch.nn as nn
import torch.nn.functional as functional
import torch.optim as optim
import torch.utils.data as data
import torchvision
import utils.logger as logger
import utils.data_wrapper as wrapper
import utils.func as func


# generator
class Gen(nn.Module):
    def __init__(self, z_dim=64, map_dim=64, image_size=28, leak=0.2, num_gpu=1):
        super(Gen, self).__init__()
        self.num_gpu = num_gpu
        self.fc = nn.Sequential(
            nn.Linear(z_dim, map_dim * 4), nn.LeakyReLU(leak),
            nn.Linear(map_dim * 4, map_dim * 4), nn.LeakyReLU(leak),
            nn.Linear(map_dim * 4, image_size * image_size), nn.Tanh())

    def forward(self, z):
        if isinstance(z.data, torch.cuda.FloatTensor) and self.num_gpu > 1:
            out = nn.parallel.data_parallel(self.fc, z, range(self.num_gpu))
        else:
            out = self.fc(z)
        return out


# positive discriminator
class PDis(nn.Module):
    def __init__(self, image_size=28, num_gpu=1):
        super(PDis, self).__init__()
        self.num_gpu = num_gpu
        self.fc = nn.Sequential(nn.Linear(image_size * image_size, 1), nn.Sigmoid())

    def forward(self, x):
        if isinstance(x.data, torch.cuda.FloatTensor) and self.num_gpu > 1:
            out = nn.parallel.data_parallel(self.fc, x, range(self.num_gpu))
        else:
            out = self.fc(x)
        return out.squeeze()


# negative discriminator
class NDis(nn.Module):
    def __init__(self, image_size=28, num_gpu=1):
        super(NDis, self).__init__()
        self.num_gpu = num_gpu
        self.fc = nn.Sequential(nn.Linear(image_size * image_size, 1), nn.Sigmoid())

    def forward(self, x):
        if isinstance(x.data, torch.cuda.FloatTensor) and self.num_gpu > 1:
            out = nn.parallel.data_parallel(self.fc, x, range(self.num_gpu))
        else:
            out = self.fc(x)
        return out.squeeze()


# unlabelled discriminator
class UDis(nn.Module):
    def __init__(self, map_dim=64, image_size=28, leak=0.2, num_gpu=1):
        super(UDis, self).__init__()
        self.num_gpu = num_gpu
        self.fc = nn.Sequential(
            nn.Linear(image_size * image_size, map_dim * 4), nn.LeakyReLU(leak),
            nn.Linear(map_dim * 4, map_dim * 4), nn.LeakyReLU(leak),
            nn.Linear(map_dim * 4, 1), nn.Sigmoid())

    def forward(self, x):
        if isinstance(x.data, torch.cuda.FloatTensor) and self.num_gpu > 1:
            out = nn.parallel.data_parallel(self.fc, x, range(self.num_gpu))
        else:
            out = self.fc(x)
        return out.squeeze()


# Gen_PU model
class PUN(object):
    def __init__(self, config):
        self.P_CLASS = config.P_CLASS
        self.N_CLASS = config.N_CLASS
        self.P_RATIO = config.P_RATIO
        self.CHANEL_DIM = config.CHANEL_DIM
        self.Z_DIM = config.Z_DIM
        self.MAP_DIM = config.MAP_DIM
        self.IMAGE_SIZE = config.IMAGE_SIZE
        self.LEAK = config.LEAK

        self.NUM_GPU = config.NUM_GPU
        self.EPOCHS = config.EPOCHS
        self.P_WEIGHT = config.P_WEIGHT
        self.PU_WEIGHT = config.PU_WEIGHT
        self.N_WEIGHT = config.N_WEIGHT
        self.NU_WEIGHT = config.NU_WEIGHT

        self.LR = config.LR
        self.BETA1 = config.BETA1
        self.BETA2 = config.BETA2
        self.SOFT_LABEL = config.SOFT_LABEL

        self.IMAGE_SET = config.IMAGE_SET
        self.IMAGE_PATH = config.IMAGE_PATH
        self.NUM_IMAGES = config.NUM_IMAGES
        self.BATCH_SIZE = config.BATCH_SIZE
        self.WORKERS = config.WORKERS

        self.VERBOSE = config.VERBOSE
        self.LOG_STEP = config.LOG_STEP
        self.LOG_PATH = config.LOG_PATH
        self.SAMPLE_STEP = config.SAMPLE_STEP
        self.SAMPLE_SIZE = config.SAMPLE_SIZE
        self.SAMPLE_PATH = config.SAMPLE_PATH
        self.MODEL_PATH = config.MODEL_PATH
        self.make_sub_dir()

        self.train_loader = None
        self.get_loader()

        self.p_gen = None
        self.n_gen = None
        self.p_dis = None
        self.n_dis = None
        self.u_dis = None
        self.p_gen_optim = None
        self.n_gen_optim = None
        self.p_dis_optim = None
        self.n_dis_optim = None
        self.u_dis_optim = None
        self.build_model()

        self.logger = None
        self.create_logger()

    def make_sub_dir(self):
        sub_dir = '/{}/pun'.format(self.IMAGE_SET)
        sub_dir += '/pc{}-nc{}'.format(self.P_CLASS, self.N_CLASS)
        sub_dir += '/pr{}'.format(self.P_RATIO)
        sub_dir += '/pw{}-puw{}-nw{}-nuw{}'.format(self.P_WEIGHT, self.PU_WEIGHT, self.N_WEIGHT, self.NU_WEIGHT)
        self.LOG_PATH += sub_dir
        self.MODEL_PATH += sub_dir
        self.SAMPLE_PATH += sub_dir
        if not os.path.exists(self.MODEL_PATH):
            os.makedirs(self.MODEL_PATH)
        if not os.path.exists(self.SAMPLE_PATH):
            os.makedirs(self.SAMPLE_PATH)

    def build_model(self):
        self.p_gen = Gen(z_dim=self.Z_DIM, map_dim=self.MAP_DIM, image_size=self.IMAGE_SIZE,
                         leak=self.LEAK, num_gpu=self.NUM_GPU)
        self.n_gen = Gen(z_dim=self.Z_DIM, map_dim=self.MAP_DIM, image_size=self.IMAGE_SIZE,
                         leak=self.LEAK, num_gpu=self.NUM_GPU)
        self.p_dis = PDis(image_size=self.IMAGE_SIZE, num_gpu=self.NUM_GPU)
        self.n_dis = NDis(image_size=self.IMAGE_SIZE, num_gpu=self.NUM_GPU)
        self.u_dis = UDis(map_dim=self.MAP_DIM, image_size=self.IMAGE_SIZE,
                          leak=self.LEAK, num_gpu=self.NUM_GPU)
        if torch.cuda.is_available():
            print('in cuda')
            self.p_gen.cuda()
            self.n_gen.cuda()
            self.p_dis.cuda()
            self.n_dis.cuda()
            self.u_dis.cuda()
        self.p_gen_optim = optim.Adam(self.p_gen.parameters(), lr=self.LR, betas=(self.BETA1, self.BETA2))
        self.n_gen_optim = optim.Adam(self.n_gen.parameters(), lr=self.LR, betas=(self.BETA1, self.BETA2))
        self.p_dis_optim = optim.Adam(self.p_dis.parameters(), lr=self.LR, betas=(self.BETA1, self.BETA2))
        self.n_dis_optim = optim.Adam(self.n_dis.parameters(), lr=self.LR, betas=(self.BETA1, self.BETA2))
        self.u_dis_optim = optim.Adam(self.u_dis.parameters(), lr=self.LR, betas=(self.BETA1, self.BETA2))

    def create_logger(self):
        self.logger = logger.Logger(self.LOG_PATH)

    def get_loader(self):
        train_set = wrapper.PUTrainSetMNIST(image_path=self.IMAGE_PATH, num_images=self.NUM_IMAGES,
                                            image_size=self.IMAGE_SIZE, p_class=self.P_CLASS,
                                            n_class=self.N_CLASS, p_ratio=self.P_RATIO,
                                            verbose=self.VERBOSE, sample_path=self.SAMPLE_PATH)
        self.train_loader = data.DataLoader(dataset=train_set, batch_size=self.BATCH_SIZE,
                                            shuffle=True, num_workers=self.WORKERS, drop_last=True)

    def reset_grad(self):
        self.p_gen.zero_grad()
        self.n_gen.zero_grad()
        self.p_dis.zero_grad()
        self.n_dis.zero_grad()
        self.u_dis.zero_grad()

    def sample_image(self, epoch, fz_var):
        samples = self.p_gen(fz_var)
        samples = samples.view(samples.size(0), self.CHANEL_DIM, self.IMAGE_SIZE, self.IMAGE_SIZE)
        torchvision.utils.save_image(func.denormalize(samples.data),
                                     os.path.join(self.SAMPLE_PATH, 'p_gen-%d.png' % epoch), nrow=20)
        samples = self.n_gen(fz_var)
        samples = samples.view(samples.size(0), self.CHANEL_DIM, self.IMAGE_SIZE, self.IMAGE_SIZE)
        torchvision.utils.save_image(func.denormalize(samples.data),
                                     os.path.join(self.SAMPLE_PATH, 'n_gen-%d.png' % epoch), nrow=20)

    def save_model(self, epoch):
        p_gen_path = os.path.join(self.MODEL_PATH, 'p_gen-%d.pkl' % epoch)
        torch.save(self.p_gen.state_dict(), p_gen_path)
        n_gen_path = os.path.join(self.MODEL_PATH, 'n_gen-%d.pkl' % epoch)
        torch.save(self.n_gen.state_dict(), n_gen_path)

    def train_model(self):
        fz = torch.randn(self.SAMPLE_SIZE, self.Z_DIM)
        fz_var = func.to_variable(fz, volatile=True)
        real_label = func.to_variable(torch.ones(self.BATCH_SIZE))
        fake_label = func.to_variable(torch.zeros(self.BATCH_SIZE))
        for epoch in range(self.EPOCHS):
            if (epoch + 1) % self.SAMPLE_STEP == 0:
                print('EPOCH [%d]' % (epoch + 1))
            for p_images, u_images in self.train_loader:
                p_images = p_images.view(self.BATCH_SIZE, -1)
                u_images = u_images.view(self.BATCH_SIZE, -1)
                reals = func.to_variable(p_images)
                u_reals = func.to_variable(u_images)
                # ========== update D networks ==========
                # ===== p_dis_net =====
                self.reset_grad()
                pz = torch.randn(self.BATCH_SIZE, self.Z_DIM)
                pz_var = func.to_variable(pz, volatile=True)
                p_fakes = func.to_variable(self.p_gen(pz_var).data)
                # train p_dis with real images
                pd_r = self.p_dis(reals)
                pd_r_loss = functional.binary_cross_entropy(pd_r, real_label * self.SOFT_LABEL)
                pd_r_loss.backward()
                # train p_dis with fake images
                pd_pf = self.p_dis(p_fakes.detach())
                pd_pf_loss = functional.binary_cross_entropy(pd_pf, fake_label)
                pd_pf_loss.backward()
                self.p_dis_optim.step()
                # ========== n_dis_net ==========
                self.reset_grad()
                nz = torch.randn(self.BATCH_SIZE, self.Z_DIM)
                nz_var = func.to_variable(nz, volatile=True)
                n_fakes = func.to_variable(self.n_gen(nz_var).data)
                # train n_dis with real images
                nd_r = self.n_dis(reals)
                nd_r_loss = functional.binary_cross_entropy(nd_r, real_label * self.SOFT_LABEL)
                nd_r_loss.backward()
                # train n_dis with n_fake images
                nd_nf = self.n_dis(n_fakes.detach())
                nd_nf_loss = functional.binary_cross_entropy(nd_nf, fake_label)
                nd_nf_loss.backward()
                self.n_dis_optim.step()
                # ===== u_dis_net =====
                self.reset_grad()
                # train u_dis with u_real images
                ud_r = self.u_dis(u_reals)
                ud_r_loss = functional.binary_cross_entropy(ud_r, real_label * self.SOFT_LABEL)
                ud_r_loss.backward()
                # train u_dis with p_fake images
                ud_pf = self.u_dis(p_fakes.detach())
                ud_pf_loss = functional.binary_cross_entropy(ud_pf, fake_label)
                ud_pf_loss.backward()
                # train u_dis with n_fake images
                ud_nf = self.u_dis(n_fakes.detach())
                ud_nf_loss = functional.binary_cross_entropy(ud_nf, fake_label)
                ud_nf_loss.backward()
                self.u_dis_optim.step()

                # ========== update G network ===========
                # ===== p_gen_net =====
                self.reset_grad()
                pz = torch.randn(self.BATCH_SIZE, self.Z_DIM)
                pz_var = func.to_variable(pz)
                p_fakes = self.p_gen(pz_var)
                # train p_gen guided by p_dis with p_fake images
                pg = self.p_dis(p_fakes)
                pg_loss = functional.binary_cross_entropy(pg, real_label)
                pg_loss = pg_loss * self.P_WEIGHT
                # train p_gen guided by pu_dis with p_fake images
                pug = self.u_dis(p_fakes)
                pug_loss = functional.binary_cross_entropy(pug, real_label)
                pug_loss = pug_loss * self.PU_WEIGHT
                p_gen_loss = pg_loss + pug_loss
                p_gen_loss.backward()
                self.p_gen_optim.step()

                # ===== n_gen_net =====
                self.reset_grad()
                nz = torch.randn(self.BATCH_SIZE, self.Z_DIM)
                nz_var = func.to_variable(nz)
                n_fakes = self.n_gen(nz_var)
                # train n_gen guided by n_dis with n_fake images
                ng = self.n_dis(n_fakes)
                ng_loss = functional.binary_cross_entropy(ng, fake_label)
                ng_loss = ng_loss * self.N_WEIGHT
                # train n_gen guided by nu_dis with n_fake images
                nug = self.u_dis(n_fakes)
                nug_loss = functional.binary_cross_entropy(nug, real_label)
                nug_loss = nug_loss * self.NU_WEIGHT
                n_gen_loss = ng_loss + nug_loss
                n_gen_loss.backward()
                self.n_gen_optim.step()
                # print info
                if self.VERBOSE:
                    # write logs
                    self.logger.plot('pd_r_loss', pd_r_loss.cpu().data.numpy())
                    self.logger.plot('pd_pf_loss', pd_pf_loss.cpu().data.numpy())
                    self.logger.plot('nd_r_loss', nd_r_loss.cpu().data.numpy())
                    self.logger.plot('nd_nf_loss', nd_nf_loss.cpu().data.numpy())
                    self.logger.plot('ud_r_loss', ud_r_loss.cpu().data.numpy())
                    self.logger.plot('ud_pf_loss', ud_pf_loss.cpu().data.numpy())
                    self.logger.plot('ud_nf_loss', ud_nf_loss.cpu().data.numpy())
                    self.logger.plot('pg_loss', pg_loss.cpu().data.numpy())
                    self.logger.plot('pug_loss', pug_loss.cpu().data.numpy())
                    self.logger.plot('ng_loss', ng_loss.cpu().data.numpy())
                    self.logger.plot('nug_loss', nug_loss.cpu().data.numpy())
                    self.logger.tick()
            if self.VERBOSE:
                # generate samples every sample step
                if (epoch + 1) % self.SAMPLE_STEP == 0:
                    self.sample_image(epoch + 1, fz_var)
                    self.save_model(epoch + 1)
                # plot logs every plot step
                if (epoch + 1) % self.LOG_STEP == 0:
                    self.logger.flush(epoch + 1)


def pun_main(config):
    # create pun gan model
    pun_gan = PUN(config)
    pun_gan.train_model()


if __name__ == '__main__':
    # positive class
    pc_list = [3]
    # negative class
    nc_list = [5]
    # percentage of positive samples as P data
    pr_list = [0.002]
    # positive weight
    pw_list = [0.01]
    puw_list = [1.0]
    # negative weight
    nw_list = [100.0]
    nuw_list = [1.0]
    for pr in pr_list:
        for pc, nc in zip(pc_list, nc_list):
            for pw, puw, nw, nuw in zip(pw_list, puw_list, nw_list, nuw_list):
                print('pr[%.4f], pc[%d]-nc[%d], pw[%.2f]-puw[%.2f]-nw[%.2f]-nuw[%.2f]'
                      % (pr, pc, nc, pw, puw, nw, nuw))
                # set parameters for generative PU model
                parser = argparse.ArgumentParser()
                # model hyper-params
                parser.add_argument('--P_CLASS', type=int, default=pc)
                parser.add_argument('--N_CLASS', type=int, default=nc)
                parser.add_argument('--P_RATIO', type=float, default=pr)
                parser.add_argument('--CHANEL_DIM', type=int, default=1)
                parser.add_argument('--Z_DIM', type=int, default=64)
                parser.add_argument('--MAP_DIM', type=int, default=64)
                parser.add_argument('--IMAGE_SIZE', type=int, default=28)
                parser.add_argument('--LEAK', type=float, default=0.2)
                # training hyper-params
                parser.add_argument('--NUM_GPU', type=int, default=1)
                parser.add_argument('--EPOCHS', type=int, default=1600)
                parser.add_argument('--P_WEIGHT', type=float, default=pw)
                parser.add_argument('--PU_WEIGHT', type=float, default=puw)
                parser.add_argument('--N_WEIGHT', type=float, default=nw)
                parser.add_argument('--NU_WEIGHT', type=float, default=nuw)
                parser.add_argument('--LR', type=float, default=0.0003)
                parser.add_argument('--BETA1', type=float, default=0.9)
                parser.add_argument('--BETA2', type=float, default=0.999)
                parser.add_argument('--SOFT_LABEL', type=float, default=1.0)
                # misc
                parser.add_argument('--IMAGE_SET', type=str, default='mnist')
                parser.add_argument('--IMAGE_PATH', type=str, default='./data')
                parser.add_argument('--NUM_IMAGES', type=int, default=5000)
                parser.add_argument('--WORKERS', type=int, default=2)
                parser.add_argument('--BATCH_SIZE', type=int, default=100)
                parser.add_argument('--VERBOSE', type=bool, default=True)
                parser.add_argument('--LOG_STEP', type=int, default=200)
                parser.add_argument('--LOG_PATH', type=str, default='./logs')
                parser.add_argument('--SAMPLE_STEP', type=int, default=20)
                parser.add_argument('--SAMPLE_SIZE', type=int, default=200)
                parser.add_argument('--SAMPLE_PATH', type=str, default='./samples')
                parser.add_argument('--MODEL_PATH', type=str, default='./models')
                args = parser.parse_args()
                # main
                pun_main(args)
